package game;

public class GameBoardFull extends GameBoard {
    public GameBoardFull() {
		super();
		SayActCell say_act1 = new SayActCell();
		SayActCell say_act2 = new SayActCell();
		SayActCell say_act3 = new SayActCell();
		SayActCell say_act4 = new SayActCell();
		say_act1.setName("SayAct1");
		say_act2.setName("SayAct2");
		say_act3.setName("SayAct3");
		say_act4.setName("SayAct4");
		
		MagicToolCell magictool1 = new MagicToolCell();
		MagicToolCell magictool2 = new MagicToolCell();
		MagicToolCell magictool3 = new MagicToolCell();
		MagicToolCell magictool4 = new MagicToolCell();
		magictool1.setName("MagicTool1");
		magictool2.setName("MagicTool2");
		magictool3.setName("MagicTool3");
		magictool4.setName("MagicTool4");
		
		EventCell event1 = new EventCell();
		EventCell event2 = new EventCell();
		EventCell event3 = new EventCell();
		EventCell event4 = new EventCell();
		EventCell event5 = new EventCell();
		event1.setName("Event1");
		event2.setName("Event2");
		event3.setName("Event3");
		event4.setName("Event4");
		event5.setName("Event5");
		
		addCell(event1);
		addCell(say_act1);
		addCell(magictool1);
		addCell(event2);
		addCell(say_act2);
		addCell(event3);
		addCell(magictool2);
		addCell(say_act3);
		addCell(event4);
		addCell(magictool3);
		addCell(say_act4);
		addCell(event5);
		addCell(magictool4);
    }
}
