package game;

public class GoCell extends Cell {
	public GoCell() {
		super.setName("Go");
	}

	public void playAction() {
	}
}
