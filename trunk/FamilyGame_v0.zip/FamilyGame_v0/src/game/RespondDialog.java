package game;

public interface RespondDialog {
    boolean getResponse();
}
