package game;

public class Player {
	private int self_esteem;
	private String name;
	private String role;
	private Cell position;
	private int playOrder;//the playing order
	
	public Player() {
		GameBoard gb = GameMaster.instance().getGameBoard();
		if(gb != null) {
			position = gb.queryCell("Go");
		}
	}
	
	public boolean isEND() {
		return self_esteem < 0;
	}

	public int getSelfEsteem() {
		return this.self_esteem;
	}
	public void setSelfEsteem(int self_esteem) {
		this.self_esteem = self_esteem;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		if(!name.equals("")) {
			this.name = name;
		}
		else {
			name = null;
		}
	}

	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		if(!role.equals("")) {
			this.role = role;
		}
		else {
			role = null;
		}
	}
	
	public void setOrder(int o) {
		playOrder=o;
	}
	
	public int getOrder() {
		return playOrder;
	}
	
	public Cell getPosition() {
		return this.position;
	}
	public void setPosition(Cell newPosition) {
		this.position = newPosition;
	}

    public String toString() {
        return name;
    }

}
