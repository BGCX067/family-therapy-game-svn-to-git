package game;

public class EventCell extends Cell {
	public void playAction() {
	}
}
