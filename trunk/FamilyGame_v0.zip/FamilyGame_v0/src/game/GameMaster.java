package game;

import java.util.ArrayList;


public class GameMaster {

	private static GameMaster gameMaster;
	static final public int MAX_PLAYER = 6;	//Maximum number of player is 6
	private Die[] dice;
	private GameBoard gameBoard;
	private GameGUI gui;
	private int initAmountOfSE;
	private ArrayList<Player> players = new ArrayList<Player>();
	private int turn = 0;
	
	public static GameMaster instance() {
		if(gameMaster == null) {
			gameMaster = new GameMaster();
		}
		return gameMaster;
	}

	public GameMaster() {
		initAmountOfSE = 5;
		dice = new Die[]{new Die(), new Die()};
	}

    public void btnSayActCardClicked() {
        gui.showSayActCardDialog(getCurrentPlayer());
    }

    public void btnEventCardClicked() {
    	gui.showEventCardDialog(getCurrentPlayer());
    }
    
    public void btnMagicToolCardClicked() {
    	gui.showMagicToolCardDialog(getCurrentPlayer());
    }

    public void btnEndTurnClicked() {
		setAllButtonEnabled(false);
		getCurrentPlayer().getPosition().playAction();
		updateGUI();
		if(getCurrentPlayer().isEND()){
			checkForWinner();
		} 
		else {
			updateGUI();
			switchTurn();
		}
    }
    
    public void btnRollDiceClicked() {
    	int[] rolls = null;
    	try {
    		rolls = rollDice();
    	}
    	catch (NullPointerException e) {
    		return;
    	}
    	if(rolls != null) {
			if((rolls[0]+rolls[1]) > 0) {
				Player player = getCurrentPlayer();
				gui.setRollDiceEnabled(false);
				StringBuffer msg = new StringBuffer();
				msg.append(player.getName())
						.append(", you rolled ")
						.append(rolls[0])
						.append(" and ")
						.append(rolls[1]);
				gui.showMessage(msg.toString());
				movePlayer(player, rolls[0] + rolls[1]);
			}
    	}
    }
	
	public Player getCurrentPlayer() {
		return getPlayer(turn);
	}
    
    public int getCurrentPlayerIndex() {
        return turn;
    }

	public GameBoard getGameBoard() {
		return gameBoard;
	}

    public GameGUI getGUI() {
        return gui;
    }

	public int getInitAmountOfSE() {
		return initAmountOfSE;
	}
	
	public int getNumberOfPlayers() {
		return players.size();
	}

    public int getNumberOfSellers() {
        return players.size() - 1;
    }

	public Player getPlayer(int index) {
		return (Player)players.get(index);
	}
	
	public int getPlayerIndex(Player player) {
		return players.indexOf(player);
	}

	public int getTurn() {
		return turn;
	}

	public void movePlayer(Player player, int diceValue) {
		Cell currentPosition = player.getPosition();
		int positionIndex = gameBoard.queryCellIndex(currentPosition.getName());
		int newIndex = (positionIndex+diceValue)%gameBoard.getCellNumber();
		player.setPosition(gameBoard.getCell(newIndex));
		gui.movePlayer(getPlayerIndex(player), positionIndex, newIndex);
		playerMoved(player);
		updateGUI();
	}

	public void playerMoved(Player player) {
		Cell cell = player.getPosition();
		int playerIndex = getPlayerIndex(player);
		if(cell instanceof EventCell) {
		    gui.setEventCardEnabled(true);
		}
		if(cell instanceof SayActCell) {
		    gui.setSayActCardEnabled(true);
		}
		if(cell instanceof MagicToolCell) {
		    gui.setMagicToolCardEnabled(true);
		}
		gui.enableEndTurnBtn(playerIndex);
        //gui.setTradeEnabled(turn, false);
	}

	public void reset() {
		for(int i = 0; i < getNumberOfPlayers(); i++){
			Player player = (Player)players.get(i);
			player.setPosition(gameBoard.getCell(0));
		}
		turn = 0;
	}
	
	public int[] rollDice() {
		return new int[]{
			dice[0].getRoll(),
			dice[1].getRoll()
		};
	}
    
	private void setAllButtonEnabled(boolean enabled) {
		gui.setRollDiceEnabled(enabled);
		gui.setSayActCardEnabled(enabled);
		gui.setEventCardEnabled(enabled);
		gui.setMagicToolCardEnabled(enabled);
		gui.setEndTurnEnabled(enabled);
        //gui.setTradeEnabled(turn, enabled);
	}

	public void setGameBoard(GameBoard board) {
		this.gameBoard = board;
	}
	
	public void setGUI(GameGUI gui) {
		this.gui = gui;
	}

	public void setInitAmountOfSE(int self_esteem) {
		this.initAmountOfSE = self_esteem;
	}

	public void setNumberOfPlayers(int number) {
		if(number >= 2 && number <= MAX_PLAYER) {
			players.clear();
			for(int i =0;i<number;i++) {
				Player player = new Player();
				player.setSelfEsteem(initAmountOfSE);
				players.add(player);
			}
		}
		else {
			players.clear();
		}
	}
	
	public void startGame() {
		gui.startGame();
		gui.enablePlayerTurn(0);
	}

	public void switchTurn() {
		turn = (turn + 1) % getNumberOfPlayers();
		if(!getCurrentPlayer().isEND()) {
			gui.enablePlayerTurn(turn);
		}
		else {
			checkForWinner();
			switchTurn();
		}
	}
	
	public void checkForWinner() {
		int numPlayersNotEND = 0;
		int playerIndex = -1;
		for(int i = 0; i < players.size(); i++) {
			if(!getPlayer(i).isEND()) {
				numPlayersNotEND++;
				playerIndex = i;
			}
		}
		//System.out.println("Number of Players " + numPlayersNotBankrupt + " " + playerIndex);
		if(numPlayersNotEND > 1) {
			return;
		}
		else {
			gui.setAllButtonsDisabled();
			gui.showWinner(playerIndex);
		}
		
	}

	public void updateGUI() {
		gui.update();
	}
}