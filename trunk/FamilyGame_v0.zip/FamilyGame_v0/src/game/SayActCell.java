package game;

public class SayActCell extends Cell {
	public void playAction() {
		
	}
}
