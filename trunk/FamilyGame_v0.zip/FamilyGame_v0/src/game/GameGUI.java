package game;

public interface GameGUI {
	public void enableEndTurnBtn(int playerIndex);
	public void enablePlayerTurn(int playerIndex);
	public boolean isSayActCardButtonEnabled();
    public boolean isEventCardButtonEnabled();
    public boolean isMagicToolCardButtonEnabled();
    public boolean isEndTurnButtonEnabled();
	public void movePlayer(int index, int from, int to);
    public void setSayActCardEnabled(boolean b);
    public void setEventCardEnabled(boolean b);
    public void setMagicToolCardEnabled(boolean b);
    public void setEndTurnEnabled(boolean enabled);
    public void setRollDiceEnabled(boolean b);
    public void showSayActCardDialog(Player currentPlayer);
    public void showEventCardDialog(Player currentPlayer);
    public void showMagicToolCardDialog(Player currentPlayer);
    public void showMessage(String string);
	public void startGame();
	public void update();
	public void showWinner(int index);
	public void setAllButtonsDisabled();
}
