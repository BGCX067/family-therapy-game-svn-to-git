package game;

import java.util.*;

public class GameBoard {

	private ArrayList<Cell> cells = new ArrayList<Cell>();
	
	public GameBoard() {
		Cell go = new GoCell();
		addCell(go);
	}
	
	public void addCell(Cell cell) {
		cells.add(cell);
	}

	public Cell getCell(int newIndex) {
		return (Cell)cells.get(newIndex);
	}
	
	public int getCellNumber() {
		return cells.size();
	}
	
	public Cell queryCell(String string) {
		for(int i = 0; i < cells.size(); i++){
			Cell temp = (Cell)cells.get(i); 
			if(temp.getName().equals(string)) {
				return temp;
			}
		}
		return null;
	}
	
	public int queryCellIndex(String string){
		for(int i = 0; i < cells.size(); i++){
			Cell temp = (Cell)cells.get(i); 
			if(temp.getName().equals(string)) {
				return i;
			}
		}
		return -1;
	}
}
