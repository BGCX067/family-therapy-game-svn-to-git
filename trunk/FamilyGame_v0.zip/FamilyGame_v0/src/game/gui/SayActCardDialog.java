
package game.gui;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;

import game.Player;

public class SayActCardDialog extends JDialog {
	private static final long serialVersionUID = 1L;

	private Player player;
	String[] task={"�V�䤤�@��a�H���@�y�Y�઺���ܡC",
			"�V�䤤�@��a�H���@�y���y�����ܡC",
			"�P�䤤�@��a�x�������R�C",
			"�V�䤤�@��a�x�����ۤ@���q�C"};

	public SayActCardDialog(Player player) {
		this.player = player;
		Container c = this.getContentPane();
		c.setLayout(new GridLayout(3, 1));
		c.add(new JLabel("���ܤΰʧ@: "));
		c.add(new JLabel(task[(int)(Math.random() * 4)]));
		c.add(buildOKButton());
		c.add(buildMagicToolButton());
		c.doLayout();
		this.pack();
	}

	private JButton buildMagicToolButton() {
		JButton btn = new JButton("Use Magic Tool");
		btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				MagicToolClicked();
			}
		});
		return btn;
	}
	
	private JButton buildOKButton() {
		JButton btn = new JButton("OK");
		btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				okClicked();
			}
		});
		return btn;
	}
	
	private void MagicToolClicked() {
		this.dispose();
	}
	
	private void okClicked() {
		player.setSelfEsteem(player.getSelfEsteem()+1);
		this.dispose();
	}
}
