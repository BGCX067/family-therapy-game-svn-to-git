
package game.gui;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;

import game.Player;


public class MagicToolCardDialog extends JDialog {
	
	private static final long serialVersionUID = 1L;
	String[] card={"�]�k�ثa",
			"�]�k�M",
			"�]�k�޵P",
			"�]�k�_��",
			"�]�k��",
			"�]�k��M"};

	private Player player;

	public MagicToolCardDialog(Player player) {
		this.player = player;
		Container c = this.getContentPane();
		c.setLayout(new GridLayout(3, 2));
		c.add(new JLabel("�]�k�D��"));
		c.add(new JLabel("�A��o"+card[(int)(Math.random() * 6)]));
		c.add(buildOKButton());
		c.add(buildCancelButton());
		c.doLayout();
		this.pack();
	}

	private JButton buildCancelButton() {
		JButton btn = new JButton("Cancel");
		btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				CancelClicked();
			}
		});
		return btn;
	}
	
	private JButton buildOKButton() {
		JButton btn = new JButton("OK");
		btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				okClicked();
			}
		});
		return btn;
	}
	
	private void CancelClicked() {
		this.dispose();
	}
	
	private void okClicked() {
		this.dispose();
	}
}
