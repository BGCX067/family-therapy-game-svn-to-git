package game.gui;

import game.Cell;

public interface CellInfoFormatter {
    public String format(Cell cell);
}
