
package game.gui;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextArea;

import game.Player;

public class EventCardDialog extends JDialog {
	private static final long serialVersionUID = 1L;
	private Player player;
	String[] task={"[例子1]仔仔(女女)學校的終期考試臨近,\n父親因為仔仔(女女)在上學期的中文考試成績得到六十分而禁止他/她於星期六出外。\n但是這星期六(女女)的好同學邀請他/她出席生日會。媽媽請決定如何解決這事情?",
			"[例子2]媽媽連續一星期內發現仔仔(女女)於晚上與學校的同班同學傾電話長達三十分鐘。\n爸爸請決定如何解決這事情？",
			"[例子3].....",
			"[例子4]....."};
	String[] ans1={"A) 應承去，但打算說謊因為其他特別事情，而不能參與。",
			"B) 雖然想去但拒絕參與，因爲怕父母不開心而推卻不參與。",
			"C) 與父母親討論溫習時間，制定新旳温習時間表，並表達自己的意願。",
			"D) 問兄姊的意見。"};
	String[] ans2={"A) 立即責罵。禁止再與同學傾電話達五分鐘以上。",
			"B) 向仔仔（女女）指出連續一星期傾電話的發現。了解傾電話的原因。\n溫和地講出自己的感受和影響。期望他們應該有節制。",
			"C) 威嚇向爸爸投訴，如不改善這星期將會被扣除零用錢。",
			"D) 不予理會。"};
	int taskno=(int)(Math.random() * 4);
	public EventCardDialog(Player player) {
		this.player = player;
		Container c = this.getContentPane();
		c.setLayout(new GridLayout(3, 1));
		c.add(new JLabel("事件: "));
		c.add(new JTextArea(task[taskno]));
		c.add(buildA_Button());
		c.add(buildB_Button());
		c.add(buildC_Button());
		c.add(buildD_Button());
		c.doLayout();
		this.pack();
	}

	private JButton buildA_Button() {
		JButton btn = new JButton();
		if (taskno==0)
		{
			btn.setText(ans1[0]);
		}
		else if (taskno==1)
		{
			btn.setText(ans2[0]);
		}
		else
			btn.setText("A");
		btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				AClicked();
			}
		});
		return btn;
	}
	private JButton buildB_Button() {
		JButton btn = new JButton();
		if (taskno==0)
		{
			btn.setText(ans1[1]);
		}
		else if (taskno==1)
		{
			btn.setText(ans2[1]);
		}
		else
			btn.setText("B");
		btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				BClicked();
			}
		});
		return btn;
	}
	private JButton buildC_Button() {
		JButton btn = new JButton();
		if (taskno==0)
		{
			btn.setText(ans1[2]);
		}
		else if (taskno==1)
		{
			btn.setText(ans2[2]);
		}
		else
			btn.setText("C");
		btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				CClicked();
			}
		});
		return btn;
	}
	private JButton buildD_Button() {
		JButton btn = new JButton();
		if (taskno==0)
		{
			btn.setText(ans1[3]);
		}
		else if (taskno==1)
		{
			btn.setText(ans2[3]);
		}
		else
			btn.setText("D");
		btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				DClicked();
			}
		});
		return btn;
	}
	
	private void AClicked() {
		if (taskno==0)
		{
			player.setSelfEsteem(player.getSelfEsteem()-2);
		}
		else if (taskno==1)
		{
			player.setSelfEsteem(player.getSelfEsteem()-2);
		}
		this.dispose();
	}
	private void BClicked() {
		if (taskno==0)
		{
			player.setSelfEsteem(player.getSelfEsteem()-1);
		}
		else if (taskno==1)
		{
			player.setSelfEsteem(player.getSelfEsteem()+2);
		}
		this.dispose();
	}
	private void CClicked() {
		if (taskno==0)
		{
			player.setSelfEsteem(player.getSelfEsteem()+2);
		}
		else if (taskno==1)
		{
			player.setSelfEsteem(player.getSelfEsteem()-1);
		}
		this.dispose();
	}
	private void DClicked() {
		if (taskno==0)
		{
			player.setSelfEsteem(player.getSelfEsteem()+1);
		}
		else if (taskno==1)
		{
			player.setSelfEsteem(player.getSelfEsteem()-1);
		}
		this.dispose();
	}
}
