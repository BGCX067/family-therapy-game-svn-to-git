package game.gui;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;

import game.*;

public class PlayerPanel extends JPanel {
	private static final long serialVersionUID = 1L;
	private JButton btnSayActCard;
	private JButton btnEventCard;
	private JButton btnMagicToolCard;
    private JButton btnEndTurn;
    private JButton btnRollDice;
    
    private JLabel lblSE;
    private JLabel lblName;
    private JLabel lblROLE;
    private JLabel lblWinner;
    
    private Player player;
    
    public PlayerPanel(Player player) {
        JPanel pnlAction = new JPanel();
        JPanel pnlInfo = new JPanel();
        btnRollDice = new JButton("Roll Dice");
        btnSayActCard = new JButton("Say/Act Card");
        btnEventCard = new JButton("Event Card");
        btnMagicToolCard = new JButton("Magic Tool Card");
        btnEndTurn = new JButton("End Turn");
        this.player = player;
        lblName = new JLabel();
        lblSE = new JLabel();
        lblROLE = new JLabel();
        lblWinner = new JLabel("Winner!");
        lblWinner.setVisible(false);

        JPanel pnlName = new JPanel();
        JPanel pnlProperties = new JPanel();

        pnlInfo.setLayout(new BorderLayout());
        pnlInfo.add(pnlName, BorderLayout.NORTH);
        pnlInfo.add(pnlProperties, BorderLayout.CENTER);

        pnlProperties.setLayout(new GridLayout(2,1));

        pnlName.add(lblName);
        pnlName.add(lblWinner);
        pnlProperties.add(lblSE);
        pnlProperties.add(lblROLE);

        pnlAction.setLayout(new GridLayout(3, 3));
        pnlAction.add(btnSayActCard);
        pnlAction.add(btnEventCard);
        pnlAction.add(btnMagicToolCard);
        pnlAction.add(btnRollDice);
        pnlAction.add(btnEndTurn);

        pnlAction.doLayout();
        pnlInfo.doLayout();
        pnlName.doLayout();
        pnlProperties.doLayout();
        this.doLayout();

        setLayout(new BorderLayout());
        add(pnlInfo, BorderLayout.CENTER);
        add(pnlAction, BorderLayout.SOUTH);

        btnRollDice.setEnabled(false);
        btnSayActCard.setEnabled(false);
        btnEventCard.setEnabled(false);
        btnMagicToolCard.setEnabled(false);
        btnEndTurn.setEnabled(false);

        setBorder(new BevelBorder(BevelBorder.RAISED));

        btnRollDice.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GameMaster.instance().btnRollDiceClicked();
            }
        });

        btnEndTurn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GameMaster.instance().btnEndTurnClicked();
            }
        });

        btnSayActCard.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GameMaster.instance().btnSayActCardClicked();
            }
        });

        btnEventCard.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GameMaster.instance().btnEventCardClicked();
            }
        });

        btnMagicToolCard.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	GameMaster.instance().btnMagicToolCardClicked();
            }
        });

    }

    public void displayInfo() {
        lblName.setText("���a: " + player.getName());
        lblSE.setText("�۴L��: " + player.getSelfEsteem());
        lblROLE.setText("\n����: " + player.getRole());
    }
    
    public boolean isSayActCardButtonEnabled() {
        return btnSayActCard.isEnabled();
    }
    public boolean isEventCardButtonEnabled() {
        return btnEventCard.isEnabled();
    }
    public boolean isMagicToolCardButtonEnabled() {
        return btnMagicToolCard.isEnabled();
    }
    public boolean isEndTurnButtonEnabled() {
        return btnEndTurn.isEnabled();
    }
    public boolean isRollDiceButtonEnabled() {
        return btnRollDice.isEnabled();
    }

    public void setSayActCardEnabled(boolean b) {
        btnSayActCard.setEnabled(b);
    }
    public void setEventCardEnabled(boolean b) {
        btnEventCard.setEnabled(b);
    }
    public void setMagicToolCardEnabled(boolean b) {
        btnMagicToolCard.setEnabled(b);
    }
    public void setEndTurnEnabled(boolean enabled) {
        btnEndTurn.setEnabled(enabled);
    }
    public void setRollDiceEnabled(boolean enabled) {
        btnRollDice.setEnabled(enabled);
    }
	
	public void setWinnerLabelVisible(boolean b){
		lblWinner.setVisible(b);
	}
}