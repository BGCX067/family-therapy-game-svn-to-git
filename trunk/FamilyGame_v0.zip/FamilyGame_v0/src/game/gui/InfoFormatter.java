package game.gui;

import java.util.Hashtable;

import game.*;

public class InfoFormatter {
    static Hashtable<Class<?>, CellInfoFormatter> cellInfoFormatters = null;
    
    static {
        if (cellInfoFormatters == null) {
            cellInfoFormatters = new Hashtable<Class<?>, CellInfoFormatter>();
            addFormatters();
        }
    }
    
    private static void addFormatters() {
        cellInfoFormatters.put(
        		SayActCell.class, new SayActCellInfoFormatter());
        cellInfoFormatters.put(
                GoCell.class, new GoCellInfoFormatter());
        cellInfoFormatters.put(
        		MagicToolCell.class, new MagicToolCellInfoFormatter());
        cellInfoFormatters.put(
        		EventCell.class, new EventCellInfoFormatter());
    }

    public static String cellInfo(Cell cell) {
        CellInfoFormatter formatter = (CellInfoFormatter) cellInfoFormatters.get(cell.getClass());
        return formatter.format(cell);
    }

}
