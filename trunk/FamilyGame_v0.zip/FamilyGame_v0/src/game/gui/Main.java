package game.gui;

import javax.swing.*;
import game.*;

public class Main{
//	JButton getOrder=new JButton("�}�l�Y��");
	JLabel iniRoll=new JLabel("");
	private static int numPlayers;
	private static int inputNumberOfPlayers(MainWindow window) {
		int numPlayers = 0;
		
		while(numPlayers < 2 || numPlayers > GameMaster.MAX_PLAYER) {
			String numberOfPlayers = JOptionPane.showInputDialog(window, "�׿�J���a�H�� (2-6)");
			if(numberOfPlayers == null) {
				System.exit(0);
			}
			try {
				numPlayers = Integer.parseInt(numberOfPlayers);
			} 
			catch (NumberFormatException e) {
				JOptionPane.showMessageDialog(window, "�п�J�Ʀr (2-6)");//input must be integer
				continue;
			}
			
			if (numPlayers < 2 || numPlayers > GameMaster.MAX_PLAYER) {
				JOptionPane.showMessageDialog(window, "�Ʀr�������G2��6!");
			} else {
				GameMaster.instance().setNumberOfPlayers(numPlayers);
			}
		}
		return numPlayers;
	}
	

private static void bubbleSort(int[][] intArray) {
	int n = intArray.length;
    int temp = 0;

    for(int i=0; i < n; i++){
    for(int j=1; j < (n-i); j++){
    	if(intArray[1][j-1] < intArray[1][j]){
    		//swap the elements!
    		temp = intArray[1][j-1];
    		intArray[1][j-1] = intArray[1][j];
    		intArray[1][j] = temp;
    		temp = intArray[0][j-1];
    		intArray[0][j-1] = intArray[0][j];
    		intArray[0][j] = temp;
    		}
    	}
    }
}

private static String printOrder() {

	String str="";
	
	for(int i = 0; i < numPlayers; i++) {
		str+=
		GameMaster.instance().getPlayer(i).getName()+"  "+
		GameMaster.instance().getPlayer(i).getOrder()+"\n";
	}
	return str;
}


	
	public static void main(String[] args) {
		GameMaster master = GameMaster.instance();
		MainWindow window = new MainWindow();
		GameBoard gameBoard = null;
		
		gameBoard = new GameBoardFull();

		master.setGameBoard(gameBoard);
		numPlayers = inputNumberOfPlayers(window);//set the actual number of players(2-6)
		int random=(int)(Math.random() * 6);//random for the number 0-5
		String[] arr = {"����","����","����","����","��l","�k��"}; //The preset roles
		
		int [][]sum= new int [2][numPlayers];//store the value of their first dice rolling
		
		for(int i = 0; i < numPlayers; i++) {
			
			sum[0][i]=i;//player id
		}
		
		//input player's names
		for(int i = 0; i < numPlayers; i++) {
			String name = "";
				
			while(name.equals("")) {
				name =JOptionPane.showInputDialog(window, "�п�J���a" + (i+1)+" ���W��");
			}
			
			GameMaster.instance().getPlayer(i).setName(name);
			
		/*	while(arr[random].equals("")) {
			random=(int)(Math.random() * 6);
			}
			
			GameMaster.instance().getPlayer(i).setRole(arr[random]);//assign a role 
			arr[random]="";*/
		}
		
		
		//alert every players to roll dice
		for(int i = 0; i < numPlayers; i++) {

			
			Die d1=new Die();
			Die d2=new Die();
			
			
			JOptionPane.showConfirmDialog(window,"�Ъ��a" + GameMaster.instance().getPlayer(i)+"�Y��l�A�H�I�ƨM�w�Y��Ω⨤�⦸�ǡC","",JOptionPane.DEFAULT_OPTION);
			sum[1][i]=d1.getRoll()+d2.getRoll();
			JOptionPane.showMessageDialog(window, "���a" + GameMaster.instance().getPlayer(i)+"�Y�F"+sum[1][i]);
			//GameMaster.instance().getPlayer(i).setName(name);
			
		while(arr[random].equals("")) {
			random=(int)(Math.random() * 6);
			}
			
			GameMaster.instance().getPlayer(i).setRole(arr[random]);//ass
			arr[random]="";
		}
		
		//alert all players the order
		//String [] info={"aa","bb","cc"};
	
		Main.bubbleSort(sum);
		
		//set the order
		for(int i = 0; i < numPlayers; i++) {
			int playerId=sum[0][i];
			int order=i+1;
		
			GameMaster.instance().getPlayer(playerId).setOrder(order);
			
		
		}
		JOptionPane.showMessageDialog(null,"�U���a�Y��Ω⨤�⦸�Ǧp�U:\n"+Main.printOrder(),null, JOptionPane.PLAIN_MESSAGE);
	
		window.setupGameBoard(gameBoard);
		window.setVisible(true);
		master.setGUI(window);
		master.startGame();
	}
	
}
