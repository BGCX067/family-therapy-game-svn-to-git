package game.gui;

import game.Cell;

public class GoCellInfoFormatter implements CellInfoFormatter {
    
    public static final String GO_text = "<html><b>Go</b></html>";
    
    public String format(Cell cell) {
        return GO_text;
    }
}