package game;

public class MagicToolCell extends Cell {
	public void playAction() {
		
	}
}
